package com.example.weightlossproject_elliotcollins;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class WeightData extends SQLiteOpenHelper {

    public WeightData(@Nullable Context context) {
        super(context, "Userdata.db", null, 1);
    }

    //creates table for weight database
    @Override
    public void onCreate(SQLiteDatabase MyDB2) {//the date acts as the primary key to create different entries
        MyDB2.execSQL("create Table userDetails(day TEXT primary key, dayWeight TEXT, goalWeight TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB2, int i, int i1) {
        MyDB2.execSQL("drop Table if exists userDetails");

    }

    public Boolean insertuserdata(String day, String dayWeight, String goalWeight) {//Populates date, weight, and goal weight for the entry
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("day", day);
        contentValues.put("dayweight", dayWeight);
        contentValues.put("goalweight", goalWeight);
        long result = MyDB2.insert("Userdetails", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }


    public Boolean updateuserdata(String day, String dayWeight, String goalWeight) {//edit the data for an entry of a given date
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dayweight", dayWeight);
        contentValues.put("goalweight", goalWeight);
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where day = ?", new String[]{day});
        if (cursor.getCount() > 0) {
            long result = MyDB2.update("Userdetails", contentValues, "day=?", new String[]{day});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }


    public Boolean deleteuserdata(String day) {//delete an entry for a given date
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where day = ?", new String[]{day});
        if (cursor.getCount() > 0) {
            long result = MyDB2.delete("Userdetails", "day=?", new String[]{day});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }


    public Cursor getData() {//View the grid
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails", null);
        return cursor;

    }
}
