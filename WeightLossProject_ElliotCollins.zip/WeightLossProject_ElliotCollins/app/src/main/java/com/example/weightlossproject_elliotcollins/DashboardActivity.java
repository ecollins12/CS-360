package com.example.weightlossproject_elliotcollins;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.Toast;

public class DashboardActivity extends AppCompatActivity {

    EditText day, dayWeight, goalWeight;
    Button insert, update, delete, view;
    Switch enable;
    WeightData DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {//creates every edit text field and button
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        day = findViewById(R.id.day);
        dayWeight = findViewById(R.id.dayWeight);
        goalWeight = findViewById(R.id.goalWeight);

        insert = findViewById(R.id.buttonInsert);
        update = findViewById(R.id.buttonUpdate);
        delete = findViewById(R.id.buttonDelete);
        view = findViewById(R.id.buttonView);
        enable = findViewById(R.id.switchEnable);
        DB = new WeightData(this);


        insert.setOnClickListener(new View.OnClickListener() {//onclick for weigh in. takes data for all 3 fields
            @Override
            public void onClick(View view) {//provides success/fail notifications
                String date = day.getText().toString();
                String weighIn = dayWeight.getText().toString();
                String goal = goalWeight.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(date, weighIn, goal);
                if (checkinsertdata == true)
                    Toast.makeText(DashboardActivity.this, "Entry Successfully Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DashboardActivity.this, "Entry Failed", Toast.LENGTH_SHORT).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {//on click for update weigh-in
            @Override
            public void onClick(View view) {
                String dayText = day.getText().toString();
                String dayWeightText = dayWeight.getText().toString();
                String goalWeightText = goalWeight.getText().toString();

                Boolean checkupdatedata = DB.updateuserdata(dayText, dayWeightText, goalWeightText);
                if (checkupdatedata == true)
                    Toast.makeText(DashboardActivity.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DashboardActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {//on click for delete entry
            @Override
            public void onClick(View view) {
                String dayText = day.getText().toString();
                Boolean checkdeletedata = DB.deleteuserdata(dayText);
                if (checkdeletedata == true)
                    Toast.makeText(DashboardActivity.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(DashboardActivity.this, "Delete Failed", Toast.LENGTH_SHORT).show();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {//on click for displaying grid as toast message
            @Override
            public void onClick(View view) {
                Cursor res = DB.getData();
                if (res.getCount() == 0) {
                    Toast.makeText(DashboardActivity.this, "No Entry", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Day :" + res.getString(0) + "\n");
                    buffer.append("Weight :" + res.getString(1) + "\n");
                    buffer.append("Goal Weight :" + res.getString(2) + "\n\n");
                }


                AlertDialog.Builder builder = new AlertDialog.Builder(DashboardActivity.this);
                builder.setCancelable(true);
                builder.setTitle("All Entries");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });
        enable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                String dayWeightText = dayWeight.getText().toString();
                String goalWeightText = goalWeight.getText().toString();
                if(isChecked){
                    if(dayWeightText.equals(goalWeightText)){
                        Toast.makeText(DashboardActivity.this, "Goal Weight Reached!", Toast.LENGTH_SHORT).show();
                    }
                }
            }




        });
    }


}